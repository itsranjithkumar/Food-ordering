- to create an expo template
    - `npx create-expo-app@latest deliverooClone --template tabs@49`
    - this will create a template application that counts, and have a small modal too


- `npx expo` 
    - will start the application
- `npx expo --clear`
    - will clear the cache

- remove the `components` folder
- add colors in `Colors.ts`
- remove the `tabs` folder in the app folder
- except _layout.tsx remove the rest of tsx in the app folder
- `npm i @gorhom/bottom-sheet`
- `npx expo install react-native-reanimated react-native-gesture-handler`

- `npm i react-native-bouncy-checkbox`
- `npx expo install react-native-maps`
- `npm install react-native-google-places-autocomplete --save`
- install react native parallax scroll view
    - https://github.com/i6mi6/react-native-parallax-scroll-view/tree/e68faeb9e87cc5aa1f2573da95838ff3079d69f2

- `npm i deprecated-react-native-prop-types`

- `npx expo install expo-haptics`
- `npm install zustand`
import { View, Text, StyleSheet, Image } from 'react-native'
import React from 'react'
import { categories } from '@/assets/data/home'
import { ScrollView } from 'react-native-gesture-handler'
const Categories = () => {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}
    contentContainerStyle={{padding:15}}
    >
      {categories.map((category, index) => (
        <View style={styles.categoryCard} key={index}>
            <Image source={category.img}/>
            <Text style={styles.CategoryText}>{category.text}</Text>
        </View>
      ))}
    </ScrollView>
  )
}

const styles = StyleSheet.create({
    categoryCard:{
        height:100,
        width:100,
        backgroundColor:"white",
        marginEnd:10,
        elevation:2,
        shadowColor:"black",
        shadowOffset:{width:0, height:2},
        shadowOpacity:0.06,
        borderRadius:4
    },
    CategoryText:{
        padding:5,
        fontSize:14,
        fontWeight:"bold",
        
    }

})

export default Categories
- to bring multiple cursors
    - press `ctrl+d`


- how to enable fast refresh in expo
    - https://stackoverflow.com/questions/62732197/why-is-expo-not-refreshing-when-i-save-changes
![alt text](image.png)
![](image-1.png)

- press `j` to open js debug console.